"use strict";
exports.id = 620;
exports.ids = [620];
exports.modules = {

/***/ 3620:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/Components/Header.js

 // import logo from "/assets/images/logo-waqf.png"


 // import { , Layout, , theme } from 'antd';





const Nav = external_styled_components_default().div.withConfig({
  displayName: "Header__Nav",
  componentId: "sc-18uk5i6-0"
})(["display:flex;gap:30px;justify-content:space-between;.login{background:#D4B265;color:#fff;border:none;height:44px;&:hover{color:#fff;}}a{color:var(--color-1);text-decoration:none;transition:all ease 0.3s;&:hover{color:var(--color-3);}}.current{position:relative;}li{list-style:none;font-weight:bold;@media (max-width:960px){margin:35px 0;}&.active-item{color:#D4B265;a{color:var(--color-3);@media (min-width:961px){display:flex;position:relative;&:after{content:\"\";width:100%;height:2px;position:absolute;left:0;background:orange;}}}}}.new-deals{position:relative;span{position:relative;img{object-fit:cover;width:4px;position:absolute;top:0;}}}"]);
const RowStyle = {
  background: "#fff",
  padding: "15px",
  direction: "rtl",
  color: "#005D5E",
  height: "120px",
  transform: "translateY(-14px)"
};
const ImageStyle = {
  height: "-wevkit-fill-available"
};

const HeaderComponent = () => {
  const router = (0,router_.useRouter)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_antd_.Row, {
    style: RowStyle,
    className: "container",
    children: [/*#__PURE__*/jsx_runtime_.jsx(external_antd_.Col, {
      lg: 8,
      children: /*#__PURE__*/jsx_runtime_.jsx("img", {
        src: "/assets/images/logo-waqf.png",
        height: 100
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(external_antd_.Col, {
      lg: 16,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Nav, {
        children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
          className: router.pathname === "/" ? "active-item" : null,
          children: /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
            href: '/',
            children: "\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: "",
          children: /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
            href: '/about',
            children: "\u0645\u0646 \u0646\u062D\u0646"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: "",
          children: /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
            href: '/wakf-library',
            children: "\u0645\u0643\u062A\u0628\u0629 \u0627\u0644\u0648\u0642\u0641"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: router.pathname === "/services" ? "active-item" : null,
          children: /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
            href: '/services',
            children: "\u062E\u062F\u0645\u0627\u062A\u0646\u0627"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: "",
          children: /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
            href: '/wakf-library',
            children: "\u0627\u0644\u0628\u0627\u0642\u0627\u062A"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: "",
          children: /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
            href: '/wakf-library',
            children: "\u0627\u0644\u0627\u0633\u062A\u0634\u0627\u0631\u0627\u062A"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: "",
          children: /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
            href: '/wakf-library',
            children: "\u0627\u062A\u0635\u0644 \u0628\u0646\u0627"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          children: /*#__PURE__*/jsx_runtime_.jsx(external_antd_.Button, {
            className: "login",
            children: "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644"
          })
        })]
      })
    })]
  });
};

/* harmony default export */ const Header = (HeaderComponent);
;// CONCATENATED MODULE: ./src/Components/Layout.js





const {
  Header: Layout_Header,
  Footer,
  Sider,
  Content
} = external_antd_.Layout;
const headerStyle = {
  textAlign: 'left',
  gap: "15px",
  color: '#fff',
  height: 60,
  paddingInline: 60,
  lineHeight: '64px',
  backgroundColor: '#005D5E'
};
const contentStyle = {
  textAlign: 'center',
  minHeight: 120,
  lineHeight: '120px',
  color: '#fff',
  // backgroundImage:url(`${mailImage}`),
  background: "url(/assets/images/slide.png)",
  backgroundRepeat: "no-repeat",
  backgroundPosition: "50% 50%",
  minHeight: "84vh"
};
const HeaderImages = {
  gap: "15px",
  height: "100%"
};
const siderStyle = {
  textAlign: 'center',
  lineHeight: '120px',
  color: '#fff',
  backgroundColor: '#3ba0e9'
};
const footerStyle = {
  textAlign: 'right',
  color: '#fff',
  backgroundColor: '#D3B166'
};
const footer1 = {
  textAlign: 'right',
  color: '#fff',
  backgroundColor: '#005D5E'
};
const BtnStyle = {
  padding: "9px 5px",
  borderRadius: "0px"
};

const LayoutComponent = ({
  children
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(external_antd_.Space, {
    direction: "vertical",
    style: {
      width: '100%'
    },
    size: [20, 20],
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_antd_.Layout, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(Layout_Header, {
        style: headerStyle,
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "container",
          style: {
            padding: "0px"
          },
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_antd_.Row, {
            style: HeaderImages,
            justify: "start",
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              style: HeaderImages,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_antd_.Button, {
                style: BtnStyle,
                children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/assets/images/ico-twitter.png",
                  width: 18,
                  height: 16,
                  alt: "twitter icon"
                }), " "]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              style: HeaderImages,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_antd_.Button, {
                style: BtnStyle,
                children: [" ", /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/assets/images/ico-insta.png",
                  width: 18,
                  height: 16,
                  alt: "instgram icon"
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              style: HeaderImages,
              children: /*#__PURE__*/jsx_runtime_.jsx(external_antd_.Button, {
                style: BtnStyle,
                children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/assets/images/linkedin.png",
                  width: 18,
                  height: 16,
                  alt: "Linkedon icon"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              style: HeaderImages,
              children: /*#__PURE__*/jsx_runtime_.jsx(external_antd_.Button, {
                style: BtnStyle,
                children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/assets/images/mail.png",
                  width: 18,
                  height: 16,
                  alt: "mail icon"
                })
              })
            })]
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(Content, {
        style: contentStyle,
        children: /*#__PURE__*/jsx_runtime_.jsx(Header, {})
      }), children, /*#__PURE__*/jsx_runtime_.jsx(Footer, {
        style: footer1,
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {})
      }), /*#__PURE__*/jsx_runtime_.jsx(Footer, {
        style: footerStyle,
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: "\u062D\u0642\u0648\u0642 \u0627\u0644\u0646\u0634\u0631 2023 \u062A\u0639\u0648\u062F \u0644\u0640 \u0634\u0631\u0643\u0629 \u0627\u0633\u062A\u062B\u0645\u0627\u0631 \u0627\u0644\u0645\u0633\u062A\u0642\u0628\u0644 \u0627\u0644\u0645\u062D\u062F\u0648\u062F\u0629 \u2329\u0648\u0642\u0641 \u0627\u0644\u0623\u0648\u0642\u0627\u0641\u232A"
        })
      })]
    })
  });
};

/* harmony default export */ const Layout = (LayoutComponent);

/***/ })

};
;